<?php
/*
Configuration options here..
*/
define("WEBSOCKET_HOST","192.168.0.1");
define("WEBSOCKET_PORT","12345");


?>
