<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" type="text/css" href="css/display.css" />
<script type="text/javascript" charset="utf-8">
var DEBUG = true;
var displayid = "<?php echo $_SERVER['REMOTE_ADDR']; ?>";
</script>
<script type="text/javascript" charset="utf-8" src="js/prototype/prototype.js" ></script>
<script type="text/javascript" src="js/ajax.js"></script>
<script type="text/javascript" charset="utf-8" src="js/slideClient.js" ></script>
<script type="text/javascript" charset="utf-8" src="js/displayajax.js" ></script>
</head>
<body>
<div class="displaywindow" id="displaycontainer" style="height:100%">
</div>
</body>
</html>