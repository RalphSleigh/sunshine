<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" type="text/css" href="css/display.css" />
<script type="text/javascript" charset="utf-8">
var DEBUG = true;
var displayid = "<?php echo $_GET['id'];?>";
</script>
<script type="text/javascript" charset="utf-8" src="js/prototype/prototype.js" ></script>
<script type="text/javascript" src="js/prototype/scriptaculous.js"></script>
<script type="text/javascript" src="js/websockets.js"></script>
<script type="text/javascript" charset="utf-8" src="js/slideClient.js" ></script>
<script type="text/javascript" charset="utf-8" src="js/messageClient.js" ></script>
<script type="text/javascript" charset="utf-8" src="js/display.js" ></script>
</head>
<body>
<div class="displaywindow" id="displaycontainer" style="height:100%">
</div>
</body>
</html>
