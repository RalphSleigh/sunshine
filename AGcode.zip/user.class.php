<?php

class User{
  var $roles = array();
  var $id;
  var $socket;
  var $handshake;
}
?>