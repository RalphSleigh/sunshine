#!/php -q
<?php  
//config
include "config.php";
//core websocket stuff
include "user.class.php";
include "websocket.class.php";
//client handlers
include "display.class.php";
include "control.class.php";
//content handlers
include "slidehandler.class.php";
include "messagehandler.class.php";
include "videohandler.class.php";
include "chathandler.class.php";

class Messageserver extends WebSocket {

	

	public $slidehandler;
	public $videohandler;
	//client handlers stored seperatly so functionality can be reused by ajax backend
	public $clienthandlers;
	
	function __construct($address,$port) {
		$this->debug = true;
		$this->slidehandler = new slidehandler();
		$this->videohandler = new videohandler();
		$this->messagehandler = new messagehandler();
		$this->chathandler = new chathandler();
		parent::__construct($address,$port);
	}

	function process($user,$msg){ //called on every message
  
		$this->say("< ".$msg);
	
		if(empty($user->roles)){ //first read from a new connection, establish what it is.
			$this->upgradeuser($user,$msg);//read type from message, create the right client handlers.
			return;
		}
		
		//message should be json object, 2 properties. msgfor->handler and data is passed through.
		
		$unencode = json_decode($msg);		
		$returnmsgs = null;
		
		
		if($unencode && isset($unencode->msgfor)) {
			switch($unencode->msgfor) {
				case 'server' : $returnmsgs = $this->servermessage($unencode->data,$user);  break; //handle messages for the server.
				case 'slidehandler' : $returnmsgs = $this->slidehandler->processmessage($unencode->data,$user);  break;
				case 'videohandler' : $returnmsgs = $this->videohandler->processmessage($unencode->data,$user);  break;
				case 'messagehandler' : $returnmsgs = $this->messagehandler->processmessage($unencode->data,$user);  break;
				case 'chathandler' : $returnmsgs = $this->chathandler->processmessage($unencode->data,$user);  break;
			}
		}
		else echo "bad JSON or no msgfor \n";
		
		if($returnmsgs) { //Loop over list of return messages and send them to any client with matching id/role.
			//print_r($returnmsgs);
			foreach($returnmsgs as $for => $returnmsg) { 			
				 /*
				$returnuser = $this->getuserbyid($for);
				if($returnuser)$this->send($returnuser->socket,json_encode($returnmsg));
				foreach($this->getusershaverole($for) as $returnuser)$this->send($returnuser->socket,json_encode($returnmsg));
				*/
				//lets make this only send each message to each user once
				
				
				
				foreach($this->users as $user) {
					if($user->id == $for){
						$this->send($user->socket,json_encode($returnmsg));
						continue;
						}
					if(in_array($for,$user->roles))$this->send($user->socket,json_encode($returnmsg));
				}
			}
		}
	}
   
   function upgradeuser($user, $msg) {
		$info = json_decode($msg);
		
		if(isset($info->id) && is_array($info->roles)) {
		
			foreach($info->roles as $role) {
			
				switch($role) {
					case 'display' : $this->clienthandlers[$info->id][$role] = new Control($info->id);  break;
					case 'control' : $this->clienthandlers[$info->id][$role] = new Display($info->id);  break;
					}
				}
				
			$user->roles = $info->roles;
			$user->id = $info->id;
		}
		else {
				$this->send($user->socket,"bad registration, disconnecting \n");
				$this->disconnect($user->socket);
		}
	}
	
	function getuserbyid($id){ //get user who has an id.
		$found=null;
		foreach($this->users as $user){
			if($user->id==$id){ $found=$user; break; }
			}
		return $found;
		}
	
	function getusershaverole($role){ //get an array of all users who have a role 
		$found=array();
		foreach($this->users as $user){
			if(in_array($role,$user->roles))$found[] = $user;
			}
		return $found;
		}
		
	
	function servermessage($data,$user) {
	
		if($data == "restart") {
			echo "\nServer Restarting\n\n";
		 /*
		$WshShell = new COM("WScript.Shell");
		$oExec = $WshShell->Exec("php server.php");		
		while($input = $oExec->StdOut->ReadLine())echo $input;
		//$oExec = $WshShell->Run("php server.php", 1, false);
		*/
		
			exit(2);
		}
		else if($data == "exit") {
			echo "\nGoodbye cruel world!!\n\n";
			exit(0);
		}
	}
}


$master = new Messageserver(WEBSOCKET_HOST,WEBSOCKET_PORT);
